"""This module allows users to interact with the DAC."""
